package view_controller;

import model.Boggle;
import javafx.application.Application;
import javafx.stage.Stage;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;

public class BoggleApp extends Application {

  public static void main(String[] args) {
    launch(args);
  }

  private Boggle game;

  public void start(Stage stage) {
    // Set up window
  }

  
}